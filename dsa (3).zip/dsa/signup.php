<?php
// Start the session
session_start();

// Database connection
$servername = "localhost";
$username = "root"; 
$password = ""; 
$dbname = "musicania";
$port = 4306;

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname, $port);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
$error = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];
    $email = $_POST['email'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $confirmPassword = $_POST['confirmPassword'];

    // Validate password match
    if ($password !== $confirmPassword) {
        $error = "Passwords do not match.";
    } elseif (strlen($username) <= 4) {
        $error = "Username must be more than 4 characters.";
    } elseif (strlen($password) <= 6) {
        $error = "Password must be greater than 6 characters.";
    } elseif (!preg_match('/[A-Z]/', $password)) {
        $error = "Password must contain at least one uppercase letter.";
    } elseif (!preg_match('/[\W_]/', $password)) {
        $error = "Password must contain at least one special character.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format.";
    } else {
        // Check for existing username or email
        $stmt = $conn->prepare("SELECT * FROM users WHERE username = ? OR email = ?");
        $stmt->bind_param("ss", $username, $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $error = "Username or email already exists.";
        } else {
            // Password hashing for security
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

            // Prepare and bind
            $stmt = $conn->prepare("INSERT INTO users (first_name, last_name, email, username, password) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("sssss", $firstName, $lastName, $email, $username, $hashedPassword);

            // Execute the statement
            if ($stmt->execute()) {
                // Redirect to login page after successful registration
                header("Location: login.php");
                exit();
            } else {
                $error = "Error: " . $stmt->error;
            }
        }

        $stmt->close();
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            margin: 0;
            font-family: 'Times New Roman', Times, serif;
            background: url("bg1.jpg") no-repeat center center fixed;
            background-size: cover;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            padding: 2rem;
        }

        .signup-container {
            background: linear-gradient(135deg, rgba(22, 125, 143, 0.8), rgba(11, 83, 90, 0.8));
            padding: 2rem;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(76, 152, 214, 0.1);
            text-align: center;
            width: 90%;
            max-width: 400px;
            border: 2px solid white;
        }

        .signup-container h1 {
            margin-bottom: 1rem;
            font-size: 2.5rem;
            color: #ff00ff;
            text-shadow: 0 0 20px rgba(255, 0, 255, 0.8), 0 0 30px rgba(255, 0, 255, 0.6);
        }

        label {
            margin-bottom: 0.5rem;
            font-weight: bold;
            color: #f28807;
        }

        input {
            margin-bottom: 1rem;
            padding: 0.5rem;
            border: 1px solid #ccc;
            border-radius: 4px;
            width: 100%;
        }

        button {
            padding: 0.5rem;
            border: none;
            border-radius: 4px;
            color: white;
            background: linear-gradient(90deg, #4CAF50, #8BC34A);
            cursor: pointer;
            width: 100%;
            transition: background 0.3s, box-shadow 0.3s;
        }

        button:hover {
            background: linear-gradient(90deg, #8BC34A, #4CAF50);
            box-shadow: 0 0 20px rgba(75, 255, 75, 0.6), 0 0 30px rgba(75, 255, 75, 0.3);
        }

        #error-message {
            color: red;
            margin-top: 1rem;
            font-weight: bold; /* Made it bolder for better visibility */
        }

        p {
            color: white; /* Ensures that the text is visible */
        }

        a {
            color: #ff00ff; /* Matching link color */
        }
    </style>
</head>
<body>
    <div class="signup-container">
        <h1>Sign Up</h1>
        <form id="signupForm" action="" method="POST">
            <label for="firstName">First Name</label>
            <input type="text" id="firstName" name="firstName" required>
            
            <label for="lastName">Last Name</label>
            <input type="text" id="lastName" name="lastName" required>
            
            <label for="email">Email</label>
            <input type="email" id="email" name="email" required>
            
            <label for="username">Username</label>
            <input type="text" id="username" name="username" required>
            
            <label for="password">Password</label>
            <input type="password" id="password" name="password" required>
            
            <label for="confirmPassword">Confirm Password</label>
            <input type="password" id="confirmPassword" name="confirmPassword" required>
            
            <button type="submit">Create Account</button>
        </form>
        <p id="error-message"><?php if (isset($error)) echo $error; ?></p>
        <p>Already have an account? <a href="login.php">Login here</a></p>
    </div>
</body>
</html>
