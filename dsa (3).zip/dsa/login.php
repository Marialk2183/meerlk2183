<?php
session_start();

// Database connection
$servername = "localhost";
$username = "root"; 
$password = ""; 
$dbname = "musicania";
$port = 4306;

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname, $port);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
$error = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get and sanitize user inputs
    $username = trim($_POST['username']);
    $password = $_POST['password'];

    // Prepare and execute the query
    $stmt = $conn->prepare("SELECT password FROM users WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();

    // Check if username exists
    if ($stmt->num_rows > 0) {
        $stmt->bind_result($hashedPassword);
        $stmt->fetch();

        // Verify the password
        if (password_verify($password, $hashedPassword)) {
            // Login successful, set session variable and redirect
            $_SESSION['username'] = $username; // Set session variable
            header("Location: song-selection.html"); // Redirect to dashboard
            exit();
        } else {
            $error = "Invalid username or password."; // General error message
        }
    } else {
        $error = "Invalid username or password."; // General error message
    }

    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            margin: 0;
            font-family: 'Times New Roman', Times, serif;
            background: url('bg2.jpg') no-repeat center center fixed;
            background-size: cover;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            padding: 2rem;
        }

        .login-container {
            background: linear-gradient(135deg, rgba(22, 125, 143, 0.8), rgba(11, 83, 90, 0.8), rgba(255, 105, 180, 0.8), rgba(0, 191, 255, 0.8));
            padding: 2rem;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(76, 152, 214, 0.1);
            text-align: center;
            width: 90%;
            max-width: 400px;
            border: 2px solid white;
        }

        .login-container h1 {
            margin-bottom: 1rem;
            color: #157e91;
            font-size: 2.5rem;
            background: linear-gradient(90deg, #ff7e5f, #feb47b);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            text-shadow: 2px 2px 5px rgba(0, 0, 0, 0.3);
        }

        label {
            margin-bottom: 0.5rem;
            font-weight: bold;
            color: #f28807;
        }

        input {
            margin-bottom: 1rem;
            padding: 0.5rem;
            border: 1px solid #ccc;
            border-radius: 4px;
            width: 100%;
            font-size: 1rem;
        }

        button {
            padding: 0.5rem;
            border: none;
            border-radius: 4px;
            color: white;
            background: linear-gradient(90deg, #4CAF50, #8BC34A);
            cursor: pointer;
            width: 100%;
            transition: background 0.3s, box-shadow 0.3s;
        }

        button:hover {
            background: linear-gradient(90deg, #8BC34A, #4CAF50);
            box-shadow: 0 0 20px rgba(75, 255, 75, 0.6), 0 0 30px rgba(75, 255, 75, 0.3);
        }

        #error-message {
            color: red;
            margin-top: 1rem;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h1>Musicania</h1>
        <form id="loginForm" action="" method="POST">
            <label for="username">Username</label>
            <input type="text" id="username" name="username" required>
            
            <label for="password">Password</label>
            <input type="password" id="password" name="password" required>
            
            <button type="submit">Login</button>                
        </form>
        <p id="error-message"><?php if (!empty($error)) echo $error; ?></p>
    </div>
</body>
</html>
